evaluation
==========

Evaluation tools for the RUSSE evaluation campaign. 
