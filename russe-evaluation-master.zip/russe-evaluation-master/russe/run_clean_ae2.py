from russe import clean_ae_fuzzy_duplicates

input_fpath = "/Users/sasha/work/russe/russe/task/ae2-train.csv"
clean_ae_fuzzy_duplicates(input_fpath, input_fpath + ".out")