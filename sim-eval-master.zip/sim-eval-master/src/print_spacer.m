function print_spacer()
    fprintf('============================================================\n')
end
